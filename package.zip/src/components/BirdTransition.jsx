import React, { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export default function BirdTransition() {
  const containerRef = useRef(null);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  useEffect(() => {
    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    
    // We only create the timeline once layout is settled.
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: containerRef.current,
          start: "top bottom",
          end: "bottom top",
          scrub: true,
        }
      });

      if (!prefersReducedMotion) {
        const vw = window.innerWidth;
        const vh = window.innerHeight;
        
        // Mobile gets a shorter flight path conceptually, though it stays inside its container bounds.
        const startX = isMobile ? -vw * 0.3 : -vw * 0.4;
        const startY = isMobile ? vh * 0.3 : vh * 0.5;
        const endX = isMobile ? vw * 0.3 : vw * 0.4;
        const endY = isMobile ? -vh * 0.3 : -vh * 0.5;

        // 1. ProjectsSection fades and scales down
        tl.to("#projects", {
          scale: 0.94,
          opacity: 0,
          transformOrigin: "center top",
          ease: "power2.inOut",
          duration: 0.3
        }, 0);

        // 2. Fly-through Text ("Portfolio")
        if (!isMobile) {
          tl.fromTo(".fly-through-text",
            { scale: 1, opacity: 0.8 },
            { scale: 40, opacity: 0, ease: "power2.in", duration: 0.5 },
            0
          );
        }

        // 3. Bird flight across the container (feels like flying forward into the scene)
        tl.fromTo(".bird-wrapper", 
          { x: -vw * 0.15, y: vh * 0.6, scale: 0.3, rotation: 10 },
          { x: vw * 0.15, y: -vh * 0.1, scale: 2.5, rotation: -10, ease: "none", duration: 1 },
          0
        );

        // 4. Morphing text intersection (only on desktop)
        if (!isMobile) {
          // Appears in the distance and settles as camera moves forward
          tl.fromTo(".settle-text-1", 
            { scale: 1.5, opacity: 0 },
            { scale: 1, opacity: 1, ease: "power2.out", duration: 0.2 },
            0.4
          );
          
          // Morph to text with pipe at 0.65
          tl.to(".settle-text-1", { opacity: 0, duration: 0.05, ease: "none" }, 0.65);
          tl.fromTo(".settle-text-2",
            { scale: 1, opacity: 0 },
            { scale: 1, opacity: 1, duration: 0.05, ease: "none" },
            0.65
          );

          // Both text fade out as Contact section comes in
          tl.to(".settle-text-2", { opacity: 0, scale: 1.1, ease: "power2.in", duration: 0.2 }, 0.8);
        }

        // 5. ContactSection fades and scales in
        tl.fromTo("#contact", 
          { scale: 0.95, opacity: 0 },
          { scale: 1, opacity: 1, transformOrigin: "center bottom", ease: "power2.inOut", duration: 0.3 },
          0.7
        );

        // 6. Ambient glows drift
        tl.to(".bird-glow-1", { x: vw * 0.2, y: -vh * 0.2, duration: 1, ease: "none" }, 0);
        tl.to(".bird-glow-2", { x: -vw * 0.2, y: vh * 0.2, duration: 1, ease: "none" }, 0);

      } else {
        // Fallback for prefers-reduced-motion: simple opacity crossfade
        tl.to("#projects", { opacity: 0, ease: "none", duration: 0.5 }, 0);
        tl.fromTo("#contact", { opacity: 0 }, { opacity: 1, ease: "none", duration: 0.5 }, 0.5);
      }
    }, containerRef);

    return () => ctx.revert();
  }, [isMobile]);

  return (
    <>
      <style>{`
        @keyframes birdFlap {
          0%, 100% { transform: scaleY(1); }
          50% { transform: scaleY(0.4); }
        }
        .bird-flap {
          animation: birdFlap 0.5s infinite ease-in-out;
          transform-origin: center;
        }
      `}</style>

      <div 
        ref={containerRef} 
        className={`relative w-full ${isMobile ? 'h-[60vh]' : 'h-[100vh]'} flex items-center justify-center overflow-hidden pointer-events-none z-20`}
      >
        {/* Glows */}
        <div className="bird-glow-1 absolute w-[500px] h-[500px] bg-[var(--glow-primary)] rounded-full blur-[120px] opacity-20 -left-[10%] top-[20%]" />
        <div className="bird-glow-2 absolute w-[600px] h-[600px] bg-[var(--accent)] rounded-full blur-[150px] opacity-10 right-[10%] bottom-[10%]" />
        
        {/* Text Layers */}
        {!isMobile && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
            {/* Fly-through text */}
            <h2 className="fly-through-text font-display text-[8rem] md:text-[12rem] font-bold text-white/50 tracking-tighter absolute">
              Portfolio
            </h2>
            
            {/* Settling text state 1 */}
            <h2 className="settle-text-1 font-display text-5xl md:text-7xl lg:text-8xl font-bold text-[var(--warm-white)] tracking-tighter absolute drop-shadow-2xl">
              Let's Talk
            </h2>

            {/* Settling text state 2 (Morphed with pipe) */}
            <h2 className="settle-text-2 font-display text-5xl md:text-7xl lg:text-8xl font-bold text-[var(--warm-white)] tracking-tighter absolute drop-shadow-2xl">
              Let's <span className="text-[var(--accent)] mx-1 font-light opacity-50">|</span> Talk
            </h2>
          </div>
        )}

        {/* Bird SVG */}
        <div className="bird-wrapper absolute z-30 flex items-center justify-center">
          <div className="bird-flap">
            <svg 
              viewBox="0 0 100 100" 
              className="w-16 h-16 md:w-24 md:h-24 fill-[var(--accent)] drop-shadow-[0_0_20px_var(--accent)]"
              style={{ transform: "rotate(15deg)" }}
            >
              {/* Simple stylized wings-spread silhouette */}
              <path d="M 50 40 C 20 20 0 50 0 50 C 15 40 35 45 50 55 C 65 45 85 40 100 50 C 100 50 80 20 50 40 Z" />
            </svg>
          </div>
        </div>
      </div>
    </>
  );
}
