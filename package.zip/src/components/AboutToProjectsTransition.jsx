import { useRef, useLayoutEffect } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export default function AboutToProjectsTransition({ aboutRef, projectsRef }) {
  const glassRef = useRef(null);
  const glowARef = useRef(null);
  const glowBRef = useRef(null);
  const wrapperRef = useRef(null);

  useLayoutEffect(() => {
    const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const aboutContent = aboutRef.current?.querySelector("[data-transition-target]") || aboutRef.current;
    const projectsHeading = projectsRef.current?.querySelector("[data-transition-target]") || projectsRef.current;

    const ctx = gsap.context(() => {
      if (prefersReduced) {
        gsap.timeline({
          scrollTrigger: {
            trigger: aboutRef.current,
            start: "bottom bottom",
            end: "bottom top",
            scrub: true,
          },
        })
          .to(aboutContent, { opacity: 0 }, 0)
          .to(projectsHeading, { opacity: 1 }, 0);
        return;
      }

      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: wrapperRef.current,
          start: "top bottom",
          end: "bottom top",
          scrub: 0.5, // tight coupling to scroll input
        },
      });

      // 1. About content pulls back: scale down + blur + fade
      if (aboutContent) {
        tl.to(aboutContent, {
          scale: 0.92,
          opacity: 0,
          filter: "blur(8px)",
          ease: "none",
        }, 0);
      }

      // 2. Glass panel expands from a small point to fill the screen
      tl.fromTo(
        glassRef.current,
        { scale: 0.05, opacity: 0 },
        { scale: 1, opacity: 1, ease: "none" },
        0.1
      ).to(
        glassRef.current,
        { opacity: 0, ease: "none" },
        0.75 // fades out again before Projects fully arrives
      );

      // 3. Ambient glow blobs drift
      tl.fromTo(glowARef.current, { x: -60, y: 40 }, { x: 40, y: -30, ease: "none" }, 0);
      tl.fromTo(glowBRef.current, { x: 60, y: -40 }, { x: -40, y: 30, ease: "none" }, 0);

      // 4. Projects heading scales up from below-100% and fades in
      if (projectsHeading) {
        tl.fromTo(
          projectsHeading,
          { scale: 0.95, opacity: 0 },
          { scale: 1, opacity: 1, ease: "none" },
          0.6
        );
      }
    });

    return () => ctx.revert();
  }, [aboutRef, projectsRef]);

  return (
    <div ref={wrapperRef} className="relative w-full h-[70vh] pointer-events-none overflow-hidden -my-[15vh] z-0 flex items-center justify-center">
      {/* Ambient glow blobs */}
      <div
        ref={glowARef}
        className="absolute top-1/3 left-1/4 w-96 h-96 rounded-full blur-3xl opacity-20"
        style={{ background: "var(--glow-primary)" }}
      />
      <div
        ref={glowBRef}
        className="absolute bottom-1/3 right-1/4 w-96 h-96 rounded-full blur-3xl opacity-15"
        style={{ background: "var(--glow-primary)" }}
      />

      {/* The glass panel itself — must have real glass styling, not a flat div */}
      <div
        ref={glassRef}
        className="glass-panel absolute w-[80vw] h-[70vh] max-w-4xl rounded-3xl"
        style={{
          opacity: 0,
          transformOrigin: "center center"
        }}
      />
    </div>
  );
}
